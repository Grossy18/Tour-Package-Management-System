package com.spring.boot.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourismManagementSystemIntcdb22Dx012Application {

	public static void main(String[] args) {
		SpringApplication.run(TourismManagementSystemIntcdb22Dx012Application.class, args);
	}

}
