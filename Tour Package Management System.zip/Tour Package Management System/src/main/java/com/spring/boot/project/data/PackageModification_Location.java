package com.spring.boot.project.data;

public class PackageModification_Location {
	private String location;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
