package com.spring.boot.project.data;

public class PackageModification_Price {
	private Integer price;

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}
}
