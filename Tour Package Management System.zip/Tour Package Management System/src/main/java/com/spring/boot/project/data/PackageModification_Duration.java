package com.spring.boot.project.data;

public class PackageModification_Duration {
	private Integer duration;

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}
}
