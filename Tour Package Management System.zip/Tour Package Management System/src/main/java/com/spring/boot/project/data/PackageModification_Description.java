package com.spring.boot.project.data;

public class PackageModification_Description {
	private String description;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
