package com.spring.boot.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourismManagementSystemIntcdb22Dx012ApplicationTests {

	@Test
	void contextLoads() {
	}

}
